#include "R2000Driver.h"
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree.hpp>



/*R2000Driver::R2000Driver(boost::asio::io_service&sock) :sock(service)
{
	memset(buffer, 0, 20480);
}


R2000Driver::~R2000Driver()
{
	return;
}*/
UINT16 R2000Driver::flag = 0;
R2000Driver::R2000Driver()
{
//	memset(buffer, 0, 20480);
	
}

R2000Driver::~R2000Driver()
{

//	isConnect = false;
}
std::string R2000Driver::TCPScanStart( std::string type, std::uint32_t watchdogtimeout, std::int32_t star_angle)
{
	boost::property_tree::ptree pt_;
//	IPAddr = IP;
	feeddogtime = watchdogtimeout;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service);
	sock.connect(ep);
	std::string datasend= "GET /cmd/request_handle_tcp?packet_type=&watchdogtimeout=&start_angle= HTTP/1.0\r\n\r\n";
	char datarecv[1024];
	size_t recvsize = 0;
	std::uint16_t errcode = 0;//2020.5.2����
	try
	{
	datasend.insert(70, std::to_string(star_angle));
	datasend.insert(40,type);
	datasend.insert(40 + type.length() + 17, std::to_string(watchdogtimeout));
//	std::cout << datasend << std::endl;
//	system("PAUSE");
	
	//memset(datarecv, '\0', 1024);
	sock.send(boost::asio::buffer(datasend));
	Sleep(50);
	recvsize = sock.receive(boost::asio::buffer(datarecv,1024));
	std::string tmp = (std::string)datarecv;
//	std::cout << tmp << std::endl;
//	system("PAUSE");
	
		tmp = tmp.substr(110, recvsize-110);// tmp.length() - 110);
											/*std::cout << tmp << std::endl;
		system("PAUSE");
		std::stringstream ss(tmp);*/
		
		std::stringstream stream;
		stream << tmp;
		boost::property_tree::read_json<boost::property_tree::ptree>(stream, pt_);

		boost::property_tree::ptree::iterator it = pt_.begin();
		uTCPPort = it->second.get<std::uint16_t>("");
		it++;
		handle = it->second.get<std::string>("");
		//�������У�2020.5.2����
		it++;
		errcode=it->second.get<std::uint16_t>("");
		
	
		if (errcode != 0)
		{
			sock.close();
			service.stop();
			return "";
		}

//		std::cout << uTCPPort<<"  :"<<handle << std::endl;
//		system("PAUSE");
	}
	catch (std::exception& e)
	{
//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		sock.close();
		service.stop();
		return "";
	}
	try
	{
		
		ep = boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string(IPAddr), 80);
		//boost::system::error_code ec;
		sock = boost::asio::ip::tcp::socket(service);
		sock.connect(ep);
		//��Ҫ����"GET /cmd/start_scanoutput?handle=%s  HTTP/1.0\r\n\r\n"
		std::string start = "GET /cmd/start_scanoutput?handle= HTTP/1.0\r\n\r\n";
		start.insert(33, handle);
		sock.send(boost::asio::buffer(start));
		Sleep(50);
		recvsize = sock.receive(boost::asio::buffer(datarecv,1024));

		//	std::cout << "asfdasldfja;" << datarecv << recvsize<<std::endl;
		//	system("PAUSE");
		sock.close();
		service.stop();
		return (std::string)datarecv;
	}
	catch (std::exception& e)
	{
		//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		sock.close();
		service.stop();
		return "";
	}
	
}
std::string R2000Driver::HttpGet(std::string command)
{
	return "1";
}
char* R2000Driver::GetTCPPointData()
{
//	TCPConnnet(IP, uTCPPort);
//	static int flag = 0;
	static boost::asio::ip::tcp::socket sock(service2);
	int time = 0;
	if (!flag)
	{
		
		boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), uTCPPort);
		boost::system::error_code ec;
	//	sock.bind(ep, ec);
		sock.connect(ep);
		boost::asio::socket_base::bytes_readable command(false);
		sock.io_control(command);

	/*	int nSize = 4096;
		boost::asio::socket_base::send_buffer_size size_option(nSize);
		sock.set_option(size_option);
		boost::asio::socket_base::receive_buffer_size size_option1(nSize);
		sock.set_option(size_option1);*/
//		Sleep(20);
	}
	flag = 1;
//	memset(buffer, 0, 40960);
//	std::cout << "GETTCP:" << IPAddr << "   " << uTCPPort << "   " << size << std::endl;
//	system("PAUSE");
	//boost::asio::ip::tcp::socket sock(service);
re:	try
	{
		size = sock.receive(boost::asio::buffer(buffer, sizeof(R2000Head)));//60
	//	size = sock.receive(boost::asio::buffer(buffer, 15200));
	}
	catch (std::exception& e)
	{
		return NULL;
	}
	if (size < sizeof(R2000Head) &&time==3)
		return NULL;
	else
	{
		time++;
		goto re;
	}
	R2000Head = (tmpData*)&buffer[0];
	try
	{
		size = sock.receive(boost::asio::buffer(&buffer[sizeof(R2000Head)], R2000Head->header_size- sizeof(R2000Head) +R2000Head->num_points_packet*(sizeof(UINT32)+sizeof(UINT16))));//TYPE B
	}
	catch (std::exception& e)
	{
		return NULL;
	}
//	feedwatchdog();
//	sock.close();
	return &buffer[0];

/*	int i = findPacketStart();
	while (i < 0)
	{
		size = sock.receive(boost::asio::buffer(buffer,60));
		if (size) i = findPacketStart();
	}
	if ((60 - i - 60) != 0)
	{
		size = sock.receive(boost::asio::buffer(&buffer[60],i+1));
		if (size != (i+1)) return NULL;
	}
	R2000Head = (tmpData*)&buffer[i];

	if (R2000Head->header_size > 60)
	{
		std::string tt;
		size= sock.receive(boost::asio::buffer(tt, R2000Head->header_size-60));
//		std::cout << "����60:" << R2000Head->header_size << std::endl;
//		system("PAUSE");
		if (size != R2000Head->header_size - 60|| R2000Head->header_size>40800)
			return NULL;
	}

	size = sock.receive(boost::asio::buffer(&buffer[i + 60], R2000Head->packet_size - 60));// R2000Head->header_size));
	if (size != (R2000Head->packet_size - R2000Head->header_size))
		return NULL;
//	std::cout << IPAddr<<"   "<<uTCPPort<<"   "<<size << std::endl;
//	system("PAUSE");
	if (size == 0) return NULL;
	i = findPacketStart();
	while (i < 0)
	{
		size = sock.receive(boost::asio::buffer(buffer,40960));
		if (size) i = findPacketStart();
	}
//	sock.close();
//	service.stop();
	feedwatchdog();
//	std::cout << i<<"   " <<size<< std::endl;
//	system("PAUSE");
//	R2000Head = (tmpData&)*&buffer[findPacketStart()];

	return &buffer[i];*/
}
bool  R2000Driver::disconnect()
{
/*	boost::asio::io_context service1;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service1);
	try {
		sock.connect(ep);
		std::string datasend = "GET /cmd/stop_scanoutput?handle=  HTTP/1.0\r\n\r\n";
		datasend.insert(32, handle);
		//	char datarecv[2048];
		//	memset(datarecv, '\0', 2048);
		//	memset(datasend, '\0', 512);
		//	strcpy(datasend, "datatttttttt");

		sock.send(boost::asio::buffer(datasend));
		Sleep(50);
		char datarecv[512];
		size_t recvsize = sock.receive(boost::asio::buffer(datarecv));
		//		std::cout <<"WD "<< datarecv << "    "<<datasend <<std::endl;
		//		system("PAUSE");
	}
	catch (boost::system::system_error e)
	{
		std::cout << e.code() << std::endl;
		return 0;
	}*/
	if (!StopGetting())
		return false;
	boost::asio::io_context service1;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service1);
	try {


		sock.connect(ep);
		std::string datasend = "GET /cmd/release_handle?handle=  HTTP/1.0\r\n\r\n";
		datasend.insert(31, handle);
		//	char datarecv[2048];
		//	memset(datarecv, '\0', 2048);
		//	memset(datasend, '\0', 512);
		//	strcpy(datasend, "datatttttttt");

		sock.send(boost::asio::buffer(datasend));
		Sleep(40);
		char datarecv[512];
		size_t recvsize = sock.receive(boost::asio::buffer(datarecv));
	}
	catch (boost::system::system_error e)
	{
	//	std::cout << e.code() << std::endl;
		return false;
	}
	delete[]buffer;
	buffer = nullptr;
	flag = 0;
	isConnect = false;
	sock.close();
	service.stop();
	service2.stop();
	return 1;
}
int R2000Driver::findPacketStart()
{
	if (size<60)
		return -1;
	for (std::size_t i = 0; i<size - 4; i++)
	{
		if (((unsigned char)buffer[i]) == 0x5c
			&& ((unsigned char)buffer[i + 1]) == 0xa2
			&& ((unsigned char)buffer[i + 2]) == 0x42
			&& ((unsigned char)buffer[i + 3]) == 0x00)
		{
			return i;
		}
	}
	return -2;
}
void R2000Driver::feedwatchdog()
{
	boost::asio::io_context service1;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service1);
	try {
		sock.connect(ep);
		std::string datasend= "GET /cmd/feed_watchdog?handle=  HTTP/1.0\r\n\r\n";
		datasend.insert(30, handle);
		//	char datarecv[2048];
		//	memset(datarecv, '\0', 2048);
		//	memset(datasend, '\0', 512);
		//	strcpy(datasend, "datatttttttt");

		sock.send(boost::asio::buffer(datasend));
/*		Sleep(20);
		char datarecv[512];
		size_t recvsize = sock.receive(boost::asio::buffer(datarecv));*///2020.5.24���Σ���ʱ�������պ��쳣����
		sock.close();
		service.stop();
//		std::cout <<"WD "<< datarecv << "    "<<datasend <<std::endl;
//		system("PAUSE");
	}
	catch (boost::system::system_error e)
	{
//		std::cout << e.code() << std::endl;
		return ;
	}
}
std::string R2000Driver::UDPScanStart(std::string LocalIP, std::uint16_t port, std::string type)
{
	char datarecv[1024];
	size_t recvsize = 0;

	boost::property_tree::ptree pt_;
	LocalIPAddr = LocalIP;
	uUDPPort = port;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service);
	try
	{
		sock.connect(ep);
		std::string datasend = "GET /cmd/request_handle_udp?address=&port=&packet_type=&watchdog=on&watchdogtimeout=90000 HTTP/1.0\r\n\r\n";
		std::string sPort=std::to_string(port);

		datasend.insert(55, type);
		datasend.insert(42, sPort);
		datasend.insert(36, LocalIP);
		//memset(datarecv, '\0', 1024);
		sock.send(boost::asio::buffer(datasend));
	//	std::cout << "WD " << datasend << "  " << std::endl;
	//	system("PAUSE");
		Sleep(45);
		recvsize = sock.receive(boost::asio::buffer(datarecv));
		std::string tmp = (std::string)datarecv;
	//	std::cout << "WD222 " << datarecv << "    " << datasend << "  " << std::endl;
	//	system("PAUSE");
	
		tmp = tmp.substr(110, recvsize - 112);// tmp.length() - 110);
											  /*std::cout << tmp << std::endl;
											  system("PAUSE");
											  std::stringstream ss(tmp);*/

		std::stringstream stream;
		stream << tmp;
		boost::property_tree::read_json<boost::property_tree::ptree>(stream, pt_);

		boost::property_tree::ptree::iterator it = pt_.begin();
//		uTCPPort = it->second.get<std::uint16_t>("");
//		it++;
		handle = it->second.get<std::string>("");
	//	std::cout <<"WD "<< datarecv << "    "<<datasend <<"  "<<handle<<std::endl;
	//	system("PAUSE");

	}
	catch (std::exception& e)
	{
//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return "";
	}
	try {


		sock.close();
		service.stop();
		ep = boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string(IPAddr), 80);
		//boost::system::error_code ec;
		sock = boost::asio::ip::tcp::socket(service);
		sock.connect(ep);
		//��Ҫ����"GET /cmd/start_scanoutput?handle=%s  HTTP/1.0\r\n\r\n"
		std::string start = "GET /cmd/start_scanoutput?handle= HTTP/1.0\r\n\r\n";
		start.insert(33, handle);
		sock.send(boost::asio::buffer(start));
		Sleep(50);
		recvsize = sock.receive(boost::asio::buffer(datarecv));
		//	std::cout << start<< "asfdasldfja;" << datarecv << recvsize<<std::endl;
		//	system("PAUSE");
		return (std::string)datarecv;
	}
	catch (std::exception& e)
	{
		//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return "";
	}
}
char* R2000Driver::GetUDPPointData()
{	
/*	boost::asio::ip::udp::socket sock(service, boost::asio::ip::udp::v4());
	boost::asio::ip::udp::endpoint romote_endpoint;
	boost::asio::socket_base::reuse_address option(true);
	sock.set_option(option);
	boost::asio::ip::udp::endpoint ep(boost::asio::ip::address::from_string(LocalIPAddr), uUDPPort);
	boost::system::error_code ec;
	sock.bind(ep, ec);

//	memset(buffer, 0, 152000);

	try
	{
		size = sock.receive_from(boost::asio::buffer(buffer, 151999), romote_endpoint);
	}
	catch (std::exception& e)
	{
		//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return nullptr;
	}


	sock.close();
//	feedwatchdog();
	return buffer;*/
	static boost::asio::ip::udp::socket sock(service,boost::asio::ip::udp::v4());
	static boost::asio::ip::udp::endpoint romote_endpoint;
	boost::asio::socket_base::reuse_address option(true);
	sock.set_option(option);
	if (!flag)
	{
		boost::asio::ip::udp::endpoint ep(boost::asio::ip::address::from_string(LocalIPAddr), uUDPPort);
		boost::system::error_code ec;
		sock.bind(ep, ec);
//		std::cout << LocalIP<< " 112233  " << uUDPPort << std::endl;
//		system("PAUSE");
	}
	flag = 1;
	memset(buffer, 0, 152000);
	
	//boost::asio::ip::tcp::socket sock(service);
	try 
	{
		size = sock.receive_from(boost::asio::buffer(buffer, 152000), romote_endpoint);
	}
	catch (std::exception& e)
	{
//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return nullptr;
	}
//	feedwatchdog();
	boost::asio::socket_base::reuse_address option1(true);
	sock.set_option(option1);
	return &buffer[0];
}
std::string R2000Driver::GetPara(std::string sPara)
{
	boost::property_tree::ptree pt_;
	boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
	boost::system::error_code ec;
	boost::asio::ip::tcp::socket sock(service);
	sock.connect(ep);
	std::string datasend = "GET /cmd/get_parameter?list= HTTP/1.0\r\n\r\n";
	char datarecv[1024];
	datasend.insert(28, sPara);
	//memset(datarecv, '\0', 1024);
	sock.send(boost::asio::buffer(datasend));
	Sleep(50);
	size_t recvsize = sock.receive(boost::asio::buffer(datarecv));
	std::string tmp = (std::string)datarecv;
	tmp = tmp.substr(110, recvsize - 110);

	sock.close();
	service.stop();
	return tmp;
}
bool R2000Driver::setScanFrequency(std::uint16_t sf)
{
	/*
std::stringstream stream;
string result="10000"; 
int n = 0; 
stream << result; stream >> n;//n����10000 


string result;
int n = 12345;
stream << n;
result =stream.str();// result����"12345"

*/
	std::string tmp;
	tmp = std::to_string(sf);
	if (SetPara("scan_frequency", tmp) != 0)
		return false;
	return true;
}
bool R2000Driver::connect(std::string IP)
{
	try
	{
		boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IP), 80);
		boost::system::error_code ec;
		boost::asio::ip::tcp::socket sock(service);

	/*	struct timeval tvSocket;
		tvSocket.tv_sec = 6;
		tvSocket.tv_usec = 0;
		boost::asio::socket_base::bytes_readable command(true);
		sock.open(boost::asio::ip::tcp::v4());	
		sock.io_control(command);
		int i=setsockopt(sock.native_handle(), SOL_SOCKET, SO_CONNECT_TIME, (const char*)&tvSocket, sizeof(tvSocket));
		setsockopt(sock.native_handle(), SOL_SOCKET, SO_RCVTIMEO, (const char*)&tvSocket, sizeof(tvSocket));
		setsockopt(sock.native_handle(), SOL_SOCKET, SO_SNDTIMEO, (const char*)&tvSocket, sizeof(tvSocket));*/
		
		sock.connect(ep);
		sock.close();
		IPAddr._Get_data() = IP._Get_data();
		IPAddr.resize(IP.size());
	//	IPAddr.ca=IP.capacity();
		if(!isConnect)
			buffer = new char[152000];
		isConnect = true;
/*		boost::asio::socket_base::bytes_readable command1(false);
		sock.io_control(command1);*/
		return 1;
	}
	catch (std::exception& e)
	{
//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return false;
	}
	

}

uint16_t R2000Driver::SetPara(std::string sParaName,std::string sPara)
{
	int16_t err = 0;
	try
	{
		boost::property_tree::ptree pt_;
		boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
		boost::system::error_code ec;
		boost::asio::ip::tcp::socket sock(service);
		sock.connect(ep);
		std::string datasend = "GET /cmd/set_parameter?= HTTP/1.0\r\n\r\n";

		datasend.insert(24, sPara);
		datasend.insert(23, sParaName);
	
	//	std::cout << datasend << std::endl;
	//	system("PAUSE");
		std::string datarecv;
		//memset(datarecv, '\0', 1024);
		sock.send(boost::asio::buffer(datasend));
		Sleep(50);
		char data[1024] = { 0 };
		size_t recvsize = sock.receive(boost::asio::buffer(data));
		datarecv = (std::string)data;
	//	std::cout << recvsize <<datarecv << std::endl;
	//	system("PAUSE");
	
	
		datarecv = datarecv.substr(110, recvsize - 110);// tmp.length() - 110);
											  /*std::cout << tmp << std::endl;
											  system("PAUSE");
											  std::stringstream ss(tmp);*/
//		std::cout << datarecv << std::endl;
//		system("PAUSE");

		std::stringstream stream;
		stream << datarecv;
		boost::property_tree::read_json<boost::property_tree::ptree>(stream, pt_);

		boost::property_tree::ptree::iterator it = pt_.begin();
		err = it->second.get<std::int16_t>("");
		sock.close();
		service.stop();
//		std::cout << err << std::endl;
//		system("PAUSE");
	}
	catch (std::exception& e)
	{
//		std::cerr << "ERROR: Exception: " << e.what() << std::endl;
		return -1;
	}

	return err;
}
bool R2000Driver::setSamplesPerScan(std::uint16_t spc)
{
	std::string tmp;
	tmp = std::to_string(spc);
	if (SetPara("samples_per_scan", tmp) != 0)
		return false;
	return true;
}
bool R2000Driver::StopGetting()
{
try {
		boost::asio::io_context service1;
		boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address::from_string(IPAddr), 80);
		boost::system::error_code ec;
		boost::asio::ip::tcp::socket sock(service1);
		std::string datasend = "GET /cmd/stop_scanoutput?handle=  HTTP/1.0\r\n\r\n";
		datasend.resize(datasend.size() + handle.size()+1);
		datasend.insert(32, handle);

		sock.connect(ep);

		//	char datarecv[2048];
		//	memset(datarecv, '\0', 2048);
		//	memset(datasend, '\0', 512);
		//	strcpy(datasend, "datatttttttt");
		
		sock.send(boost::asio::buffer(datasend));
		Sleep(40);
		char datarecv[512];
		size_t recvsize = sock.receive(boost::asio::buffer(datarecv,512));
		//		std::cout <<"WD "<< datarecv << "    "<<datasend <<std::endl;
		//		system("PAUSE");
		sock.close();
		service.stop();
		service2.stop();
		service1.stop();
	}
	catch (boost::system::system_error e)
	{
//		std::cout << e.code() << std::endl;
		return false;
	}
	return true;
}
bool R2000Driver::SetCW_CCW(int Direction)
{
	if (isConnect)
	{
		int r = -1;
		if(Direction==1)
			r=SetPara("scan_direction", "ccw");
		else
			r=SetPara("scan_direction", "cw");
		if (r != 0)
			return false;
		return true;
	}

}