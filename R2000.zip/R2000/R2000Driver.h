#include <iostream>
#include <array>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include "boost/asio/buffer.hpp"
#include "string.h"


#pragma once
class R2000Driver

{


public:
	R2000Driver();

	~R2000Driver();
	void feedwatchdog();
	std::string TCPScanStart(std::string type, std::uint32_t watchdogtimeout, std::int32_t star_angle);
	char* GetTCPPointData();
	std::string HttpGet( std::string command);
	uint16_t SetPara(std::string sParaName, std::string sPara);
	std::string UDPScanStart( std::string LocalIP, std::uint16_t port, std::string type);
	char* GetUDPPointData();
	std::string GetPara(std::string sPara);
	bool disconnect();
	bool StopGetting();
	bool setScanFrequency(std::uint16_t sf);
	bool setSamplesPerScan(std::uint16_t spc);
	bool SetCW_CCW(int Direction);//1:CCW,2:CW
	bool connect(std::string IP);
	struct tmpData
	{
		UINT16 magic;
		UINT16 packet_type;
		UINT32 packet_size;
		UINT16 header_size;
		UINT16 scan_number;
		UINT16 packet_number;
		UINT64 timestamp_raw;
		UINT64 timestamp_sync;
		//	UINT32 status_flags;
		UINT16 status_flags;
		UINT16 scan_frequency;
		UINT16 status_flags1;
		UINT16 num_points_scan;
		UINT16 num_points_packet;
		UINT16 first_index;
		INT32 first_angle;
		INT32 angular_increment;
		UINT32 output_status;
		UINT32 field_status;
	}*R2000Head;
	static UINT16 flag;
	size_t size;
	
private:
	char *buffer = nullptr;
	int findPacketStart();
	boost::asio::io_context service;
	boost::asio::io_context service2;
	uint16_t uTCPPort;
	uint16_t uUDPPort;
	std::string handle;
	std::string LocalIPAddr;
	std::string	IPAddr;
	std::uint32_t feeddogtime;
	bool isConnect = false;
//	boost::asio::ip::tcp::socket sock;

};

